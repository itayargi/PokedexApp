from flask import Flask, jsonify, request, abort
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes by default

POKEMON_DB_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "pokemon_db.json"))
CAPTURED_DB_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "captured_pokemon.json"))

# Utility functions to load and save Pokémon data
def load_pokemon_data():
    if os.path.exists(POKEMON_DB_PATH):
        with open(POKEMON_DB_PATH, "r") as f:
            return json.load(f)
    return []

def load_captured_pokemon():
    if os.path.exists(CAPTURED_DB_PATH):
        with open(CAPTURED_DB_PATH, "r") as f:
            return json.load(f)
    return {}

def save_captured_pokemon(captured_pokemon):
    with open(CAPTURED_DB_PATH, "w") as f:
        json.dump(captured_pokemon, f)

@app.route('/icon/<name>')
def get_icon_url(name: str):
    return f"https://img.pokemondb.net/sprites/silver/normal/{name}.png"

@app.route('/')
def hello():
    try:
        data = load_pokemon_data()
        return jsonify(data)
    except Exception as e:
        print(f"Error fetching data: {e}")
        abort(500, description="Internal Server Error")

@app.route('/pokemon')
def get_pokemon():
    try:
        print("Received request on /pokemon")
        data = load_pokemon_data()  # Load all Pokémon data
        
        # Get query parameters for filtering, pagination
        type_filter = request.args.get('type')
        search_query = request.args.get('search')
        page = int(request.args.get('page', 1))  # Default to page 1 if not provided
        limit = int(request.args.get('limit', 20))  # Default to 20 items per page if not provided

        # Filter by type if the type query parameter is provided
        if type_filter:
            type_filter = type_filter.lower()
            data = [
                pokemon for pokemon in data 
                if type_filter in (pokemon.get('type_one', '').lower(), pokemon.get('type_two', '').lower())
            ]

        # Fuzzy-text search across all properties
        if search_query:
            search_query = search_query.lower()
            data = [
                pokemon for pokemon in data
                if any(search_query in str(value).lower() for value in pokemon.values())
            ]

        # Implement pagination by slicing the list
        start = (page - 1) * limit
        end = start + limit
        paginated_data = data[start:end]

        return jsonify(paginated_data)
    except Exception as e:
        print(f"Error processing request: {e}")
        abort(500, description="Internal Server Error")

@app.route('/release', methods=['POST'])
def release_pokemon():
    try:
        data = request.json
        pokemon_name = data.get('name')
        if not pokemon_name:
            return jsonify({"error": "Invalid request"}), 400

        captured_pokemon = load_captured_pokemon()
        if pokemon_name in captured_pokemon:
            del captured_pokemon[pokemon_name]  # Remove the Pokémon from captured list
            save_captured_pokemon(captured_pokemon)

        return jsonify({"message": f"{pokemon_name} released!"})
    except Exception as e:
        print(f"Error releasing Pokémon: {e}")
        abort(500, description="Internal Server Error")


@app.route('/capture', methods=['POST'])
def capture_pokemon():
    try:
        data = request.json
        pokemon_name = data.get('name')
        if not pokemon_name:
            return jsonify({"error": "Invalid request"}), 400

        captured_pokemon = load_captured_pokemon()
        if pokemon_name not in captured_pokemon:
            captured_pokemon[pokemon_name] = True
            save_captured_pokemon(captured_pokemon)

        return jsonify({"message": f"{pokemon_name} captured!"})
    except Exception as e:
        print(f"Error capturing Pokémon: {e}")
        abort(500, description="Internal Server Error")

@app.route('/captured', methods=['GET'])
def get_captured_pokemon():
    try:
        captured_pokemon = load_captured_pokemon()
        all_pokemon = load_pokemon_data()

        captured_pokemon_details = [
            pokemon for pokemon in all_pokemon if pokemon['name'] in captured_pokemon
        ]

        return jsonify(captured_pokemon_details)
    except Exception as e:
        print(f"Error fetching captured Pokémon: {e}")
        abort(500, description="Internal Server Error")

if __name__ == '__main__':
    print(app.url_map)  # Prints all routes
    app.run(port=8080)
